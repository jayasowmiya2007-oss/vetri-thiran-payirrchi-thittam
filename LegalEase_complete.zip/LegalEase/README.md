# LegalEase — AI-Powered Legal Document Generator

This is a complete runnable implementation of the supplied LegalEase project documentation.

Features:
- Streamlit frontend
- FastAPI backend
- Gemini AI generation
- Editable document preview
- TXT, DOCX and PDF export
- Optional logo branding
- Demo mode for testing without an API key
- Automated tests
- Docker support

The supplied document specifies Gemini 1.5 Pro. The current Google Python SDK is `google-genai`, so the model is configurable with `GEMINI_MODEL`. This keeps the documented architecture while allowing a currently available Gemini model to be selected.

## Project structure

```text
LegalEase/
├── backend/
│   ├── __init__.py
│   ├── main.py
│   └── routes.py
├── ai_core/
│   ├── __init__.py
│   └── gemini_generator.py
├── services/
│   ├── __init__.py
│   └── document_formatter.py
├── utils/
│   ├── __init__.py
│   └── sanitize.py
├── frontend/
│   └── app.py
├── assets/
│   └── logo.svg
├── tests/
│   ├── test_api.py
│   └── test_formatters.py
├── docker/
│   └── start.sh
├── .env.example
├── .gitignore
├── Dockerfile
├── Procfile
├── requirements.txt
└── README.md
```

## VS Code setup — Windows

Open the LegalEase folder in VS Code.

PowerShell:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell activation is blocked, use Command Prompt:

```cmd
.venv\Scriptsctivate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Administrator mode is normally not required. If your computer blocks installation, use Administrator mode only when permitted by your administrator.

## Environment

Copy `.env.example` to `.env`.

For real Gemini AI:

```text
GEMINI_API_KEY=your_api_key_here
GEMINI_MODEL=gemini-3.8-flash
ALLOW_DEMO_MODE=false
BACKEND_URL=http://127.0.0.1:8000
```

For testing without a key:

```text
GEMINI_API_KEY=
GEMINI_MODEL=gemini-3.8-flash
ALLOW_DEMO_MODE=true
BACKEND_URL=http://127.0.0.1:8000
```

Never commit `.env`.

## Run backend

Terminal 1:

```powershell
.\.venv\Scripts\Activate.ps1
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Check:
- http://127.0.0.1:8000/
- http://127.0.0.1:8000/health
- http://127.0.0.1:8000/docs

## Run frontend

Terminal 2:

```powershell
.\.venv\Scripts\Activate.ps1
streamlit run frontend/app.py
```

Open:
http://localhost:8501

## Test the application

Example:
- Document Type: `Freelance Work Contract`
- Parties: `Jane Doe (Service Provider), TechNova Inc. (Client)`
- Terms: `Payment within 30 days of invoice; Confidentiality must be maintained; Either party may terminate with 15 days notice`
- Effective Date: any appropriate date

Click **Generate Document**, then edit if needed and download TXT, DOCX and PDF.

## Automated tests

```powershell
pytest -q
```

## API test

PowerShell:

```powershell
$body = @{
  document_type = "NDA"
  parties = "Alice (Disclosing Party), Bob (Receiving Party)"
  terms = "Confidentiality; No disclosure without permission; Return information on termination"
  effective_date = "2026-10-01"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://127.0.0.1:8000/generate" -Method Post -ContentType "application/json" -Body $body
```

## Docker

```powershell
docker build -t legalease .
docker run --env-file .env -p 8000:8000 -p 8501:8501 legalease
```

## Documentation mapping

Activity 1: Streamlit + FastAPI + Gemini + formatters architecture.

Activity 2: Generation, editing and TXT/DOCX/PDF export.

Activity 3: `backend/main.py` and `backend/routes.py` with `/generate`.

Activity 4: Streamlit inputs, preview, editing, logo upload and downloads.

Activity 5: requirements, environment configuration, Procfile, Dockerfile and tests.

LegalEase creates draft legal content. It is not a substitute for qualified legal review, and generated documents should be checked for the relevant jurisdiction and facts before use.
