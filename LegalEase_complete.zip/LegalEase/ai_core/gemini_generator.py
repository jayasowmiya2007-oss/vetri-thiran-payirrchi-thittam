import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass
class GenerationResult:
    content: str
    model: str
    demo_mode: bool


class GeminiDocumentGenerator:
    SYSTEM_INSTRUCTION = """You are LegalEase, a legal-document drafting assistant.
Create a professional DRAFT legal document from the supplied facts.

Rules:
- Do not invent names, dates, amounts, addresses, laws, or obligations not supported by the input.
- Preserve the user's requested terms.
- Use clear formal legal drafting.
- Organize the document with a title, numbered sections, signature blocks, and a short review notice.
- Clearly mark the result as a DRAFT.
- Do not claim that the draft is legally valid in a particular jurisdiction.
- If information is missing, use [NOT PROVIDED] instead of guessing.
- Do not include markdown code fences.
"""

    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY", "").strip()
        self.model_name = os.getenv("GEMINI_MODEL", "gemini-3.8-flash").strip()
        self.allow_demo = os.getenv("ALLOW_DEMO_MODE", "false").lower() == "true"

    def _build_prompt(self, document_type, parties, terms, effective_date, additional_instructions):
        return f"""Draft a {document_type}.

PARTIES:
{parties}

EFFECTIVE DATE:
{effective_date}

TERMS AND CONDITIONS:
{terms}

ADDITIONAL INSTRUCTIONS:
{additional_instructions or "[NONE]"}

Return only the draft document text.
"""

    def _demo_document(self, document_type, parties, terms, effective_date, additional_instructions):
        items = [item.strip() for item in terms.split(";") if item.strip()]
        terms_block = "\n".join(
            f"{index}. {item}" for index, item in enumerate(items, 1)
        ) or "1. [NOT PROVIDED]"

        return f"""DRAFT {document_type.upper()}

Effective Date: {effective_date}

PARTIES

{parties}

1. PURPOSE

This draft {document_type} records the arrangement described by the parties
and is prepared from the information supplied to LegalEase.

2. TERMS AND CONDITIONS

{terms_block}

3. GENERAL PROVISIONS

The parties should review all factual details, obligations, dates, amounts,
definitions, governing-law requirements, and termination provisions before
using this draft.

4. SIGNATURES

Party 1: ______________________________
Name: _________________________________
Date: __________________________________

Party 2: ______________________________
Name: _________________________________
Date: __________________________________

REVIEW NOTICE

This document is a draft generated from user-provided information. It is not
legal advice and should be reviewed by an appropriately qualified professional
for the relevant jurisdiction and circumstances.

Additional instructions:
{additional_instructions or "[NONE]"}
"""

    def generate_document(self, document_type, parties, terms, effective_date, additional_instructions=""):
        if not self.api_key:
            if self.allow_demo:
                return GenerationResult(
                    content=self._demo_document(
                        document_type, parties, terms, effective_date, additional_instructions
                    ),
                    model="demo-mode",
                    demo_mode=True,
                )
            raise RuntimeError(
                "GEMINI_API_KEY is missing. Add it to .env or set ALLOW_DEMO_MODE=true."
            )

        try:
            from google import genai
            from google.genai import types

            client = genai.Client(api_key=self.api_key)
            prompt = self._build_prompt(
                document_type, parties, terms, effective_date, additional_instructions
            )

            response = client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    system_instruction=self.SYSTEM_INSTRUCTION,
                    temperature=0.2,
                    max_output_tokens=6000,
                ),
            )

            text = (response.text or "").strip()
            if not text:
                raise RuntimeError("Gemini returned an empty response.")

            return GenerationResult(
                content=text,
                model=self.model_name,
                demo_mode=False,
            )
        except Exception as exc:
            raise RuntimeError(f"Gemini generation failed: {exc}") from exc
