from io import BytesIO
from pathlib import Path
from typing import Optional

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from fpdf import FPDF

from utils.sanitize import sanitize_text


def _lines(text: str):
    return [line.strip() for line in sanitize_text(text).splitlines()]


def format_txt(text: str) -> bytes:
    return sanitize_text(text).encode("utf-8")


def format_docx(text: str, doc_type: str, logo_bytes: Optional[bytes] = None) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.75)
    section.bottom_margin = Inches(0.75)
    section.left_margin = Inches(0.85)
    section.right_margin = Inches(0.85)

    if logo_bytes:
        paragraph = doc.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = paragraph.add_run()
        run.add_picture(BytesIO(logo_bytes), width=Inches(1.4))

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(doc_type.upper())
    run.bold = True
    run.font.name = "Times New Roman"
    run.font.size = Pt(16)

    for line in _lines(text):
        if not line:
            doc.add_paragraph()
            continue

        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(5)

        heading = (
            line.isupper()
            or line.endswith(":")
            or (len(line) < 90 and line[:2].isdigit() and "." in line[:4])
        )
        r = p.add_run(line)
        r.bold = heading
        r.font.name = "Times New Roman"
        r.font.size = Pt(11)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer_run = footer.add_run(
        "LegalEase - AI-generated draft. Review before legal use."
    )
    footer_run.font.name = "Times New Roman"
    footer_run.font.size = Pt(8)

    output = BytesIO()
    doc.save(output)
    return output.getvalue()


class BrandedPDF(FPDF):
    def __init__(self, logo_path: Optional[str] = None):
        super().__init__()
        self.logo_path = logo_path

    def header(self):
        if self.logo_path and Path(self.logo_path).exists():
            try:
                self.image(self.logo_path, x=90, y=8, w=30)
                self.ln(20)
            except Exception:
                self.ln(5)
        else:
            self.set_font("Times", "B", 10)
            self.cell(0, 8, "LegalEase", align="C")
            self.ln(6)

    def footer(self):
        self.set_y(-15)
        self.set_font("Times", "", 8)
        self.cell(
            0, 10,
            f"LegalEase - AI-generated draft | Page {self.page_no()}",
            align="C",
        )


def format_pdf(text: str, doc_type: str, logo_bytes: Optional[bytes] = None) -> bytes:
    temp_logo = None
    if logo_bytes:
        temp_logo = "/tmp/legalease_logo.png"
        Path(temp_logo).write_bytes(logo_bytes)

    pdf = BrandedPDF(temp_logo)
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_page()

    pdf.set_font("Times", "B", 16)
    pdf.cell(0, 12, doc_type.upper(), align="C")
    pdf.ln(14)

    for line in _lines(text):
        if not line:
            pdf.ln(3)
            continue

        heading = (
            line.isupper()
            or line.endswith(":")
            or (len(line) < 90 and line[:2].isdigit() and "." in line[:4])
        )
        pdf.set_font("Times", "B" if heading else "", 11)
        pdf.multi_cell(0, 6, line)
        pdf.ln(1)

    return bytes(pdf.output())
