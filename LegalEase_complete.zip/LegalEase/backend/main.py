from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routes import router

app = FastAPI(
    title="LegalEase API",
    description="AI-powered legal document drafting API.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {
        "name": "LegalEase API",
        "status": "running",
        "docs": "/docs",
        "generate_endpoint": "/generate",
    }

@app.get("/health")
def health():
    return {"status": "ok"}

app.include_router(router)
