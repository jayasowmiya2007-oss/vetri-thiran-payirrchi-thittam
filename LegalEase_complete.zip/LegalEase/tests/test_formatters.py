from docx import Document

from services.document_formatter import format_docx, format_pdf, format_txt


def test_txt_export():
    output = format_txt("Hello LegalEase")
    assert output == b"Hello LegalEase"


def test_docx_export(tmp_path):
    output = format_docx("TITLE\n\n1. First clause", "NDA")
    assert output[:2] == b"PK"

    path = tmp_path / "test_legalease.docx"
    path.write_bytes(output)

    doc = Document(path)
    assert "TITLE" in "\n".join(p.text for p in doc.paragraphs)


def test_pdf_export():
    output = format_pdf("TITLE\n\n1. First clause", "NDA")
    assert output.startswith(b"%PDF")
