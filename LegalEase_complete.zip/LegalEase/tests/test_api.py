import os

from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["status"] == "running"


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_generate_demo(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "")
    monkeypatch.setenv("ALLOW_DEMO_MODE", "true")

    from ai_core.gemini_generator import GeminiDocumentGenerator

    generator = GeminiDocumentGenerator()
    result = generator.generate_document(
        "NDA",
        "Alice (Disclosing Party), Bob (Receiving Party)",
        "Confidentiality; No disclosure",
        "2026-10-01",
    )

    assert result.demo_mode is True
    assert "DRAFT NDA" in result.content
