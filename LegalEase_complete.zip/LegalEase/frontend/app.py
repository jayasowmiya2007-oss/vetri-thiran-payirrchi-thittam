import html
import os
from datetime import date

import requests
import streamlit as st
from dotenv import load_dotenv

from services.document_formatter import format_docx, format_pdf, format_txt
from utils.sanitize import sanitize_text

load_dotenv()

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")

BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

st.markdown(
    """
    <style>
    .hero {
        padding: 1.5rem;
        border-radius: 18px;
        background: linear-gradient(135deg, #101828, #1d2939);
        color: white;
        margin-bottom: 1rem;
    }
    .hero h1 { margin: 0; }
    .hero p { color: #d0d5dd; }
    .preview {
        background: #101828;
        color: #f2f4f7;
        padding: 1.2rem;
        border-radius: 14px;
        min-height: 420px;
        max-height: 650px;
        overflow-y: auto;
        white-space: pre-wrap;
        font-family: Georgia, serif;
        line-height: 1.6;
    }
    .notice {
        padding: .75rem 1rem;
        border-left: 4px solid #98a2b3;
        background: #f9fafb;
        border-radius: 8px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "logo.svg")

col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    if os.path.exists(logo_path):
        st.image(logo_path, width=140)
    st.markdown(
        """
        <div class="hero">
            <h1>LegalEase</h1>
            <p>AI-powered legal document drafting, editing and export.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

st.markdown(
    '<div class="notice">LegalEase creates drafts. Review the document for your jurisdiction and circumstances before use.</div>',
    unsafe_allow_html=True,
)

st.divider()

if "document" not in st.session_state:
    st.session_state.document = ""
if "model" not in st.session_state:
    st.session_state.model = ""
if "edited" not in st.session_state:
    st.session_state.edited = False

left, right = st.columns([1, 1.35])

with left:
    st.subheader("1. Document details")

    document_type = st.text_input(
        "Document type",
        value="Freelance Work Contract",
    )

    parties = st.text_area(
        "Parties involved",
        value="Jane Doe (Service Provider), TechNova Inc. (Client)",
        height=110,
    )

    terms = st.text_area(
        "Terms & conditions",
        value=(
            "Payment within 30 days of invoice; "
            "Confidentiality must be maintained; "
            "Either party may terminate with 15 days notice"
        ),
        height=150,
        help="Separate clauses with semicolons.",
    )

    effective_date = st.date_input("Effective date", value=date.today())

    additional_instructions = st.text_area(
        "Additional instructions (optional)",
        placeholder="Any wording, structure, or formatting preference...",
        height=100,
    )

    logo = st.file_uploader("Optional logo", type=["png", "jpg", "jpeg"])

    if st.button("Generate Document", type="primary", use_container_width=True):
        if not document_type.strip() or not parties.strip() or not terms.strip():
            st.error("Please complete document type, parties, and terms.")
        else:
            payload = {
                "document_type": document_type.strip(),
                "parties": parties.strip(),
                "terms": terms.strip(),
                "effective_date": effective_date.isoformat(),
                "additional_instructions": additional_instructions.strip(),
            }

            with st.spinner("Generating document..."):
                try:
                    response = requests.post(
                        f"{BACKEND_URL}/generate",
                        json=payload,
                        timeout=90,
                    )
                    response.raise_for_status()
                    data = response.json()
                    st.session_state.document = sanitize_text(data["content"])
                    st.session_state.model = data.get("model", "")
                    st.session_state.edited = False
                    st.success(
                        "Document generated successfully"
                        + (" in demo mode." if data.get("demo_mode") else ".")
                    )
                except requests.RequestException as exc:
                    st.error(
                        "Could not reach the FastAPI backend. "
                        "Start it with: uvicorn backend.main:app --reload"
                    )
                    st.exception(exc)

with right:
    st.subheader("2. Preview & edit")

    if st.session_state.document:
        safe_preview = html.escape(st.session_state.document)
        st.markdown(
            f'<div class="preview">{safe_preview}</div>',
            unsafe_allow_html=True,
        )

        if st.button("Click to Edit Document", use_container_width=True):
            st.session_state.edited = True

        if st.session_state.edited:
            edited_text = st.text_area(
                "Editable document",
                value=st.session_state.document,
                height=500,
            )
            if st.button("Save Edits", use_container_width=True):
                st.session_state.document = sanitize_text(edited_text)
                st.session_state.edited = False
                st.rerun()

        st.caption(f"Generation model: {st.session_state.model or 'unknown'}")

        st.subheader("3. Download")

        logo_bytes = logo.getvalue() if logo else None
        txt_bytes = format_txt(st.session_state.document)
        docx_bytes = format_docx(
            st.session_state.document,
            document_type,
            logo_bytes=logo_bytes,
        )
        pdf_bytes = format_pdf(
            st.session_state.document,
            document_type,
            logo_bytes=logo_bytes,
        )

        d1, d2, d3 = st.columns(3)

        with d1:
            st.download_button(
                "Download TXT",
                data=txt_bytes,
                file_name="legalease_document.txt",
                mime="text/plain",
                use_container_width=True,
            )

        with d2:
            st.download_button(
                "Download DOCX",
                data=docx_bytes,
                file_name="legalease_document.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                use_container_width=True,
            )

        with d3:
            st.download_button(
                "Download PDF",
                data=pdf_bytes,
                file_name="legalease_document.pdf",
                mime="application/pdf",
                use_container_width=True,
            )
    else:
        st.info("Generate a document to see the editable preview and downloads.")

st.divider()
st.caption("LegalEase • FastAPI + Streamlit + Gemini")
